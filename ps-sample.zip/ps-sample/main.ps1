. .\misc.ps1

 

  while ($true) {

    Write-Output "---"

    Start-Sleep 5

    Get-Version

  }