function Get-Version {

    $PSVersionTable.PSVersion

  }